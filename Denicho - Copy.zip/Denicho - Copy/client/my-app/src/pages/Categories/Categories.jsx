// src/pages/Categories/Categories.jsx
import React, { useRef } from 'react';
import Product from '../../components/Product/Product';
import './Categories.css';
import { IoIosArrowBack, IoIosArrowForward } from 'react-icons/io'; // Asegúrate de instalar react-icons

const CategoriesPage = () => {
    const categories = [
        {
            name: "Tecnología",
            products: [
                { name: "App1", price: 10, image: "https://via.placeholder.com/100" },
                { name: "App2", price: 15, image: "https://via.placeholder.com/100" },
                { name: "App3", price: 20, image: "https://via.placeholder.com/100" },
                { name: "App4", price: 25, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
                { name: "App5", price: 30, image: "https://via.placeholder.com/100" },
            ]
        },
        // Agrega más categorías si es necesario
    ];

    const scrollRef = useRef(null);

    const scroll = (direction) => {
        const { scrollLeft, clientWidth } = scrollRef.current;
        const scrollAmount = direction === 'left' ? scrollLeft - clientWidth : scrollLeft + clientWidth;
        scrollRef.current.scrollTo({ left: scrollAmount, behavior: 'smooth' });
    };

    const handleTouchStart = (e) => {
        scrollRef.current.startX = e.touches[0].clientX - scrollRef.current.offsetLeft;
        scrollRef.current.scrollLeft = scrollRef.current.scrollLeft;
    };

    const handleTouchMove = (e) => {
        const x = e.touches[0].clientX - scrollRef.current.offsetLeft;
        const walk = (x - scrollRef.current.startX) * 2; // Sensibilidad del desplazamiento
        scrollRef.current.scrollLeft -= walk; // Desplazamiento a la izquierda
    };

    return (
        <div className="categories-page">
            {categories.map((category, index) => (
                <div key={index} className="category-section">
                    <h1>{category.name}</h1>
                    <div className="chevron-container">
                        <button className="chevron left" onClick={() => scroll('left')}>
                            <IoIosArrowBack />
                        </button>
                        <div
                            className="product-scroll"
                            ref={scrollRef}
                            onTouchStart={handleTouchStart}
                            onTouchMove={handleTouchMove}
                        >
                            <div className="product-scroll-container">
                                {category.products.map((product, idx) => (
                                    <div key={idx} className="product-item">
                                        <Product product={product} />
                                    </div>
                                ))}
                            </div>
                        </div>
                        <button className="chevron right" onClick={() => scroll('right')}>
                            <IoIosArrowForward />
                        </button>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default CategoriesPage;
