import React, { useState, useEffect } from 'react';
import './Register.css';

const RegisterForm = ({ onSwitch, onClose }) => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Registro: ', { username, email, password });
        // Aquí puedes manejar la lógica de registro
    };



    return (
        <div className="register">


            <div className="auth-container">
                <div className="form">
                    <h2>Bienvenido a Denicho</h2>
                    <form onSubmit={handleSubmit}>
                        <div>
                            <label>Nombre de Usuario</label>
                            <input
                                type="text"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                            />
                        </div>
                        <div>
                            <label>Email</label>
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>
                        <div>
                            <label>Contraseña</label>
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit">Registrarse</button>
                    </form>
                    <a href="/login">
                        <p>¿Ya tienes cuenta? <span onClick={onSwitch}>Inicia sesión aquí</span></p>
                    </a>
                </div>
            </div>


        </div>
    );
};

export default RegisterForm;
